<?php

require "common.php";
require theme_file('site.php');

/** 
 * #### 详情页开发 ###
 * 变量说明
 * $group_name          所在分组名称
 * $group_icon          所在分组图标
 * $url_id              链接ID
 * $url_name            链接名称
 * $url_herf            链接地址
 * $url_icon            链接图标
 * $url_title           网站标题(在线获取)
 * $url_keywords        网站关键词(在线获取)
 * $url_description     网站描述(优先本地)在线获取
 **/





